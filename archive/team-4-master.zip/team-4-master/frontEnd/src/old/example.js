module.exports = [
    {
        "location": {
            "lat": "23.51033",
            "long": "90.24176"
        },
        "issue": "This is a Sample Issue",
        "phone": "+447948547728",
        "categories": [
            "Education",
            "Mobility"
        ]
    },
    {
        "location": {
            "lat": "23.51050",
            "long": "90.24200"
        },
        "issue": "Second Issue",
        "phone": "+447948547728",
        "categories": [
            "Mobility"
        ]
    }
]
