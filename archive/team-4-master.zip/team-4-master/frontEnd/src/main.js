// Sass
require('normalize.css');
require('./style/__app.scss');

// Javascript
require('./app/app.js');
